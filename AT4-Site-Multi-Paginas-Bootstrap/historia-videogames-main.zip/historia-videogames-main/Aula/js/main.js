const feedbackForm = document.querySelector('#feedbackForm');
const formStatus = document.querySelector('#formStatus');

if (feedbackForm && formStatus) {
  feedbackForm.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!feedbackForm.reportValidity()) return;
    formStatus.textContent = 'Obrigado! Sua mensagem foi registrada nesta demonstração.';
    feedbackForm.reset();
  });
}